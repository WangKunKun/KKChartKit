import UIKit

/// Internal, per-draw contour cache. Reuse actual source primitives instead of re-interpolating
/// a subset of its points (which changes monotone tangents at the new endpoints).
enum LineStackedAreaGeometry {
    struct Edge {
        let start: CGPoint
        let end: CGPoint
        let controls: (CGPoint, CGPoint)?

        func append(to path: UIBezierPath, reversed: Bool = false) {
            if let controls {
                path.addCurve(to: reversed ? start : end,
                              controlPoint1: reversed ? controls.1 : controls.0,
                              controlPoint2: reversed ? controls.0 : controls.1)
            } else { path.addLine(to: reversed ? start : end) }
        }
    }

    struct Segment {
        let indices: [Int]
        let points: [CGPoint]
        let edges: [Edge]
        /// Offsets into `edges` at each original data point, including staircase verticals.
        let offsets: [Int]

        init(indices: [Int], points: [CGPoint], style: LineConnectionStyle) {
            self.indices = indices; self.points = points
            var edges: [Edge] = [], offsets = [0]
            if style == .smooth, let first = points.first {
                let curve = UIBezierPath(); curve.move(to: first)
                CartesianGeometry.appendSmoothCurve(to: curve, points: points)
                var current = first
                curve.cgPath.applyWithBlock { pointer in
                    let element = pointer.pointee
                    switch element.type {
                    case .addCurveToPoint:
                        edges.append(.init(start: current, end: element.points[2],
                                           controls: (element.points[0], element.points[1])))
                        current = element.points[2]; offsets.append(edges.count)
                    case .addLineToPoint:
                        edges.append(.init(start: current, end: element.points[0], controls: nil))
                        current = element.points[0]; offsets.append(edges.count)
                    default: break
                    }
                }
            } else {
                for (a, b) in zip(points, points.dropFirst()) {
                    let step = CartesianGeometry.steppedScreenPoints([a, b], style: style)
                    for (p, q) in zip(step, step.dropFirst()) {
                        edges.append(.init(start: p, end: q, controls: nil))
                    }
                    offsets.append(edges.count)
                }
            }
            self.edges = edges; self.offsets = offsets
        }

        func append(to path: UIBezierPath) {
            guard let first = points.first else { return }
            path.move(to: first)
            for edge in edges { edge.append(to: path) }
        }
    }

    struct Slice {
        let indices: ArraySlice<Int>
        let edges: ArraySlice<Edge>
    }

    struct Contour {
        let segments: [Segment]
        private let locations: [Int: (segment: Int, point: Int)]

        init(indices: [[Int]], points: [[CGPoint]], style: LineConnectionStyle) {
            segments = zip(indices, points).map { Segment(indices: $0, points: $1, style: style) }
            var locations: [Int: (segment: Int, point: Int)] = [:]
            for (s, segment) in segments.enumerated() {
                for (p, index) in segment.indices.enumerated() { locations[index] = (s, p) }
            }
            self.locations = locations
        }

        var path: UIBezierPath {
            let path = UIBezierPath()
            for segment in segments { segment.append(to: path) }
            return path
        }

        /// Never cross a source's gap break, or invent a curve at an absent source point.
        func slice(from first: Int, through last: Int) -> Slice? {
            guard let a = locations[first], let b = locations[last],
                  a.segment == b.segment, a.point < b.point else { return nil }
            let segment = segments[a.segment]
            return .init(indices: segment.indices[a.point...b.point],
                         edges: segment.edges[segment.offsets[a.point]..<segment.offsets[b.point]])
        }
    }

    /// Return along exact shared source edges. A transition with no common source is a straight
    /// connector between the original stack bases, not a claim of seamless continuous stacking.
    static func appendBaseline(to path: UIBezierPath, series: Int, indices: [Int], base: [Double],
                               model: CartesianChartModel, drawValues: [[Double]], rawValues: [[Double]],
                               contours: [Int: Contour], point: (Int, Double) -> CGPoint) {
        guard let last = indices.last else { return }
        path.addLine(to: point(last, base[last]))
        let key = model.stackKey(for: series)
        for (left, right) in zip(indices, indices.dropFirst()).reversed() {
            let raw = rawValues[series]
            let a = raw.indices.contains(left) ? raw[left] : 0
            let b = raw.indices.contains(right) ? raw[right] : 0
            let positive = a >= 0 && b >= 0
            let negative = a <= 0 && b <= 0
            var shared: Slice?
            if positive || negative {
                for previous in (0..<series).reversed() {
                    guard model.stackKey(for: previous) == key,
                          right < model.series[previous].data.count,
                          let slice = contours[previous]?.slice(from: left, through: right),
                          matches(drawValues[previous][left], base[left]),
                          matches(drawValues[previous][right], base[right]),
                          slice.indices.allSatisfy({ index in
                              let value = rawValues[previous][index]
                              return value.isFinite && (positive ? value >= 0 : value <= 0)
                          }) else { continue }
                    shared = slice; break
                }
            }
            if let shared, let end = shared.edges.last?.end {
                // Keep the source's exact endpoint too (stack subtraction may round differently).
                path.addLine(to: end)
                for edge in shared.edges.reversed() { edge.append(to: path, reversed: true) }
            } else {
                path.addLine(to: point(right, base[right]))
                path.addLine(to: point(left, base[left]))
            }
        }
    }

    private static func matches(_ a: Double, _ b: Double) -> Bool {
        a.isFinite && b.isFinite && abs(a - b) <= max(1, max(abs(a), abs(b))) * 1e-12
    }
}
