#!/usr/bin/env python3
"""Inspect a built HYMCharts.framework; emit a portable dependency/resource audit."""
from pathlib import Path
import hashlib, json, subprocess, sys
framework = Path(sys.argv[1]).resolve()
assert framework.name == 'HYMCharts.framework' and framework.is_dir()
files = sorted(p for p in framework.rglob('*') if p.is_file())
header = framework / 'Headers/HYMCharts-Swift.h'
assert 'HYMCartesianChartViewBridge' in header.read_text()
interfaces = list((framework / 'Modules').rglob('*.swiftinterface'))
assert interfaces
for p in interfaces:
    text = p.read_text()
    for name in ['LineChart','ColumnChart','BarChart','CombinedChart','HeatmapChart','RadarChart']:
        assert f'public struct {name} :' in text, (p, name)
    assert 'ChartSelfTest' not in text and 'CartesianChartDemo' not in text
for p in files:
    assert p.suffix not in {'.js','.html','.xcassets'}, p
    assert not any(x in p.name.lower() for x in ['aachart','highcharts','fixture','demo']), p
binary = framework / 'HYMCharts'
links = subprocess.check_output(['xcrun','otool','-L',str(binary)],text=True)
assert '@rpath/HYMCharts.framework/HYMCharts' in links, links
assert not any(x in links for x in ['WebKit','AAChart','Highcharts','SwiftFunctionProject'])
print(json.dumps(dict(framework=str(framework),binarySHA256=hashlib.sha256(binary.read_bytes()).hexdigest(),
    dependencies=links.splitlines(),files=[str(p.relative_to(framework)) for p in files],
    checks=['generated Objective-C header','six public SwiftUI wrappers','@rpath install name','no AA/JS/WebKit/App dependency or fixture/Demo resources']),ensure_ascii=False,indent=2))
