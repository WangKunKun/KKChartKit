import UIKit
import SwiftUI
import HYMCharts

@main final class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    func application(_ application: UIApplication, didFinishLaunchingWithOptions options: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        let window = UIWindow(frame: UIScreen.main.bounds)
        window.rootViewController = IntegrationController()
        window.makeKeyAndVisible(); self.window = window
        return true
    }
}

/// This client deliberately uses only the framework's public Swift API.
private final class IntegrationController: UIViewController {
    private let chart = HYMChartView<LineChartRenderer>(frame: .zero)
    private let status = UILabel()
    private let hit = UILabel()
    override func viewDidLoad() {
        super.viewDidLoad(); view.backgroundColor = .systemBackground
        status.frame = CGRect(x: 20, y: 70, width: 350, height: 70)
        status.numberOfLines = 0; status.accessibilityIdentifier = "integration-status"
        hit.frame = CGRect(x: 20, y: 480, width: 350, height: 70)
        hit.numberOfLines = 0; hit.accessibilityIdentifier = "integration-hit"
        chart.frame = CGRect(x: 10, y: 150, width: 370, height: 310)
        view.addSubview(chart); view.addSubview(status); view.addSubview(hit)
        let model = CartesianChartModel(series: [.init(name: "Stable series", data: Array(repeating: 100, count: 48), id: "power")], xAxis: .init(kind: .category(labels: (0..<48).map(String.init))))
        var theme = CartesianChartTheme(); theme.legend.isEnabled = true
        chart.configure(model: model, theme: theme); chart.layoutIfNeeded()
        chart.isZoomEnabled = true; chart.showCategoryRange(10..<30)
        var visibility: [Bool] = []
        chart.onSeriesVisibilityChanged = { id, visible in if id == "power" { visibility.append(visible) } }
        chart.setSeriesVisible(false, for: "power")
        var updated = model; updated.series[0].name = "Renamed series"
        updated.series[0].data = Array(repeating: 500, count: 48)
        chart.update(model: updated); chart.layoutIfNeeded()
        let keptHidden = chart.isSeriesVisible("power") == false
        chart.setSeriesVisible(true, for: "power"); chart.resetViewport()
        chart.onHit = { [weak self] target, _ in
            guard let source = target as? CartesianHitDataSource,
                  let datum = source.chartData.first else { return }
            self?.hit.text = "hit:\(datum.seriesID):\(Int(datum.rawValue ?? -1))"
        }
        // Compile the shipped SwiftUI wrapper through ordinary import as well.
        let wrapper = UIHostingController(rootView: LineChart(model: updated, playsAnimationOnAppear: false))
        wrapper.loadViewIfNeeded()
        var released = 0
        for _ in 0..<30 {
            weak var weakChart: UIView?
            autoreleasepool {
                let temporary = HYMChartView<LineChartRenderer>(frame: chart.frame)
                temporary.configure(model: updated, theme: theme); temporary.layoutIfNeeded()
                weakChart = temporary
            }
            if weakChart == nil { released += 1 }
        }
        let passed = keptHidden && visibility == [false, true] && released == 30
        status.text = "\(passed ? "PASS" : "FAIL") Swift | update=500 | visibility=\(visibility.count) | released=\(released)/30"
    }
}
