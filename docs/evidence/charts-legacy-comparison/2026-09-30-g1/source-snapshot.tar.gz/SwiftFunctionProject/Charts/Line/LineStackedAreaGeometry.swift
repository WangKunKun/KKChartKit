import UIKit

/// Internal, per-draw contour cache. Reuse actual source primitives instead of re-interpolating
/// a subset of its points (which changes monotone tangents at the new endpoints).
enum LineStackedAreaGeometry {
    struct Edge {
        let start: CGPoint
        let end: CGPoint
        let controls: (CGPoint, CGPoint)?

        func append(to path: UIBezierPath, reversed: Bool = false) {
            if let controls {
                path.addCurve(to: reversed ? start : end,
                              controlPoint1: reversed ? controls.1 : controls.0,
                              controlPoint2: reversed ? controls.0 : controls.1)
            } else { path.addLine(to: reversed ? start : end) }
        }
    }

    struct Segment {
        let indices: [Int]
        let points: [CGPoint]
        let edges: [Edge]
        /// Offsets into `edges` at each original data point, including staircase verticals.
        let offsets: [Int]

        init(indices: [Int], points: [CGPoint], edges: [Edge], offsets: [Int]) {
            self.indices = indices; self.points = points
            self.edges = edges; self.offsets = offsets
        }

        init(indices: [Int], points: [CGPoint], style: LineConnectionStyle) {
            self.indices = indices; self.points = points
            var edges: [Edge] = [], offsets = [0]
            if style == .smooth, let first = points.first {
                let curve = UIBezierPath(); curve.move(to: first)
                CartesianGeometry.appendSmoothCurve(to: curve, points: points)
                var current = first
                curve.cgPath.applyWithBlock { pointer in
                    let element = pointer.pointee
                    switch element.type {
                    case .addCurveToPoint:
                        edges.append(.init(start: current, end: element.points[2],
                                           controls: (element.points[0], element.points[1])))
                        current = element.points[2]; offsets.append(edges.count)
                    case .addLineToPoint:
                        edges.append(.init(start: current, end: element.points[0], controls: nil))
                        current = element.points[0]; offsets.append(edges.count)
                    default: break
                    }
                }
            } else {
                for (a, b) in zip(points, points.dropFirst()) {
                    let step = CartesianGeometry.steppedScreenPoints([a, b], style: style)
                    for (p, q) in zip(step, step.dropFirst()) {
                        edges.append(.init(start: p, end: q, controls: nil))
                    }
                    offsets.append(edges.count)
                }
            }
            self.edges = edges; self.offsets = offsets
        }

        func append(to path: UIBezierPath) {
            guard let first = points.first else { return }
            path.move(to: first)
            for edge in edges { edge.append(to: path) }
        }
    }

    struct Slice {
        let indices: ArraySlice<Int>
        let edges: ArraySlice<Edge>
    }

    struct Contour {
        let segments: [Segment]
        private let locations: [Int: (segment: Int, point: Int)]

        init(indices: [[Int]], points: [[CGPoint]], style: LineConnectionStyle) {
            self.init(segments: zip(indices, points).map { Segment(indices: $0, points: $1, style: style) })
        }

        init(segments: [Segment]) {
            self.segments = segments
            var locations: [Int: (segment: Int, point: Int)] = [:]
            for (s, segment) in segments.enumerated() {
                for (p, index) in segment.indices.enumerated() { locations[index] = (s, p) }
            }
            self.locations = locations
        }

        var path: UIBezierPath {
            let path = UIBezierPath()
            for segment in segments { segment.append(to: path) }
            return path
        }

        /// Never cross a source's gap break, or invent a curve at an absent source point.
        func slice(from first: Int, through last: Int) -> Slice? {
            guard let a = locations[first], let b = locations[last],
                  a.segment == b.segment, a.point < b.point else { return nil }
            let segment = segments[a.segment]
            return .init(indices: segment.indices[a.point...b.point],
                         edges: segment.edges[segment.offsets[a.point]..<segment.offsets[b.point]])
        }
    }

    /// Only borrow a boundary when both endpoints belong to the same sign chain and every
    /// intervening source sample belongs to it. Missing source endpoints/breaks are not invented.
    private static func sharedBaseline(series: Int, left: Int, right: Int, base: [Double],
                                       model: CartesianChartModel, drawValues: [[Double]],
                                       rawValues: [[Double]], contours: [Int: Contour]) -> Slice? {
        let raw = rawValues[series]
        let a = raw.indices.contains(left) ? raw[left] : 0
        let b = raw.indices.contains(right) ? raw[right] : 0
        let positive = a >= 0 && b >= 0, negative = a <= 0 && b <= 0
        guard positive || negative else { return nil }
        let key = model.stackKey(for: series)
        for previous in (0..<series).reversed() {
            guard model.stackKey(for: previous) == key,
                  right < model.series[previous].data.count,
                  let slice = contours[previous]?.slice(from: left, through: right),
                  matches(drawValues[previous][left], base[left]),
                  matches(drawValues[previous][right], base[right]),
                  slice.indices.allSatisfy({ index in
                      let value = rawValues[previous][index]
                      return value.isFinite && (positive ? value >= 0 : value <= 0)
                  }) else { continue }
            return slice
        }
        return nil
    }

    /// Add an interpolated, same-sign thickness to the exact lower boundary. The sum of
    /// piecewise linear/cubic functions is exact; no flattening, sampling or value clamping.
    static func followingBaseline(_ contour: Contour, series: Int, base: [Double],
                                  style: LineConnectionStyle, model: CartesianChartModel,
                                  drawValues: [[Double]], rawValues: [[Double]],
                                  contours: [Int: Contour], point: (Int, Double) -> CGPoint) -> Contour {
        let segments = contour.segments.map { segment -> Segment in
            let thickness = Segment(indices: segment.indices,
                points: zip(segment.indices, segment.points).map { index, top in
                    CGPoint(x: top.x, y: top.y - point(index, base[index]).y)
                }, style: style)
            var edges: [Edge] = [], offsets = [0]
            for (i, pair) in zip(segment.indices, segment.indices.dropFirst()).enumerated() {
                if let source = sharedBaseline(series: series, left: pair.0, right: pair.1,
                    base: base, model: model, drawValues: drawValues, rawValues: rawValues, contours: contours),
                   let sum = adding(Array(source.edges),
                       Array(thickness.edges[thickness.offsets[i]..<thickness.offsets[i + 1]])) {
                    edges.append(contentsOf: sum)
                } else {
                    edges.append(contentsOf: segment.edges[segment.offsets[i]..<segment.offsets[i + 1]])
                }
                offsets.append(edges.count)
            }
            return Segment(indices: segment.indices, points: segment.points, edges: edges, offsets: offsets)
        }
        return Contour(segments: segments)
    }

    /// Both paths run left to right. Vertical stair edges are retained at their original X;
    /// other edges are split at the union of knots before adding their Y coordinates.
    private static func adding(_ base: [Edge], _ thickness: [Edge]) -> [Edge]? {
        guard var p = base.first?.start, var q = thickness.first?.start,
              p.x == q.x, base.last?.end.x == thickness.last?.end.x else { return nil }
        var a = 0, b = 0, result: [Edge] = []
        func sum(_ p: CGPoint, _ q: CGPoint) -> CGPoint { CGPoint(x: p.x, y: p.y + q.y) }
        while a < base.count || b < thickness.count {
            if a < base.count, base[a].start.x == base[a].end.x {
                let end = base[a].end
                result.append(Edge(start: sum(p, q), end: sum(end, q), controls: nil))
                p = end; a += 1; continue
            }
            if b < thickness.count, thickness[b].start.x == thickness[b].end.x {
                let end = thickness[b].end
                result.append(Edge(start: sum(p, q), end: sum(p, end), controls: nil))
                q = end; b += 1; continue
            }
            guard a < base.count, b < thickness.count else { return nil }
            let x = min(base[a].end.x, thickness[b].end.x)
            let lower = portion(base[a], from: p.x, to: x)
            let delta = portion(thickness[b], from: q.x, to: x)
            let controls: (CGPoint, CGPoint)?
            if lower.controls == nil && delta.controls == nil { controls = nil }
            else {
                let lc = cubicControls(lower), dc = cubicControls(delta)
                controls = (sum(lc.0, dc.0), sum(lc.1, dc.1))
            }
            result.append(Edge(start: sum(lower.start, delta.start), end: sum(lower.end, delta.end), controls: controls))
            p = lower.end; q = delta.end
            if x == base[a].end.x { a += 1 }
            if x == thickness[b].end.x { b += 1 }
        }
        return result
    }

    private static func cubicControls(_ edge: Edge) -> (CGPoint, CGPoint) {
        if let controls = edge.controls { return controls }
        return (CGPoint(x: edge.start.x + (edge.end.x - edge.start.x) / 3,
                        y: edge.start.y + (edge.end.y - edge.start.y) / 3),
                CGPoint(x: edge.end.x - (edge.end.x - edge.start.x) / 3,
                        y: edge.end.y - (edge.end.y - edge.start.y) / 3))
    }

    /// Our monotone cubics have linear X(t). Restrict a polynomial without changing its shape.
    private static func portion(_ edge: Edge, from x0: CGFloat, to x1: CGFloat) -> Edge {
        if x0 == edge.start.x && x1 == edge.end.x { return edge }
        let width = edge.end.x - edge.start.x
        let t0 = (x0 - edge.start.x) / width, t1 = (x1 - edge.start.x) / width
        let controls = cubicControls(edge)
        let y0 = edge.start.y, y1 = controls.0.y, y2 = controls.1.y, y3 = edge.end.y
        func value(_ t: CGFloat) -> CGFloat {
            let u = 1 - t
            return u * u * u * y0 + 3 * u * u * t * y1 + 3 * u * t * t * y2 + t * t * t * y3
        }
        func slope(_ t: CGFloat) -> CGFloat {
            let u = 1 - t
            return 3 * (u * u * (y1 - y0) + 2 * u * t * (y2 - y1) + t * t * (y3 - y2))
        }
        let start = CGPoint(x: x0, y: value(t0)), end = CGPoint(x: x1, y: value(t1))
        return Edge(start: start, end: end, controls: edge.controls == nil ? nil : (
            CGPoint(x: x0 + (x1 - x0) / 3, y: start.y + slope(t0) * (t1 - t0) / 3),
            CGPoint(x: x1 - (x1 - x0) / 3, y: end.y - slope(t1) * (t1 - t0) / 3)))
    }

    /// Return along exact shared source edges. A transition with no common source is a straight
    /// connector between the original stack bases, not a claim of seamless continuous stacking.
    static func appendBaseline(to path: UIBezierPath, series: Int, indices: [Int], base: [Double],
                               model: CartesianChartModel, drawValues: [[Double]], rawValues: [[Double]],
                               contours: [Int: Contour], point: (Int, Double) -> CGPoint) {
        guard let last = indices.last else { return }
        path.addLine(to: point(last, base[last]))
        for (left, right) in zip(indices, indices.dropFirst()).reversed() {
            let shared = sharedBaseline(series: series, left: left, right: right, base: base,
                model: model, drawValues: drawValues, rawValues: rawValues, contours: contours)
            if let shared, let end = shared.edges.last?.end {
                // Keep the source's exact endpoint too (stack subtraction may round differently).
                path.addLine(to: end)
                for edge in shared.edges.reversed() { edge.append(to: path, reversed: true) }
            } else {
                path.addLine(to: point(right, base[right]))
                path.addLine(to: point(left, base[left]))
            }
        }
    }

    private static func matches(_ a: Double, _ b: Double) -> Bool {
        a.isFinite && b.isFinite && abs(a - b) <= max(1, max(abs(a), abs(b))) * 1e-12
    }
}
