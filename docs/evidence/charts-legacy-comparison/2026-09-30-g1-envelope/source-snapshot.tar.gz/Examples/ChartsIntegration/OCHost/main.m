#import <UIKit/UIKit.h>
#import <HYMCharts/HYMCharts-Swift.h>

@interface IntegrationController : UIViewController
@property(nonatomic, strong) HYMCartesianChartViewBridge *bridge;
@property(nonatomic, strong) UILabel *hit;
@end
@implementation IntegrationController
- (void)viewDidLoad {
    [super viewDidLoad]; self.view.backgroundColor = UIColor.systemBackgroundColor;
    UILabel *status = [[UILabel alloc] initWithFrame:CGRectMake(20, 70, 350, 70)];
    status.numberOfLines = 0; status.accessibilityIdentifier = @"integration-status";
    self.hit = [[UILabel alloc] initWithFrame:CGRectMake(20, 480, 350, 70)];
    self.hit.numberOfLines = 0; self.hit.accessibilityIdentifier = @"integration-hit";
    self.bridge = [[HYMCartesianChartViewBridge alloc] initWithKind:HYMCartesianChartKindLine frame:CGRectMake(10, 150, 370, 310)];
    self.bridge.stackedAreaFollowsBaseline = YES; // Generated Objective-C header compile check.
    [self.view addSubview:self.bridge.chartView]; [self.view addSubview:status]; [self.view addSubview:self.hit];
    HYMCartesianSeries *series = [HYMCartesianSeries new]; series.identifier = @"power"; series.name = @"Stable series";
    NSMutableArray *categories = [NSMutableArray array], *values = [NSMutableArray array], *updated = [NSMutableArray array];
    for (NSInteger i = 0; i < 48; i++) { [categories addObject:@(i).stringValue]; [values addObject:@100]; [updated addObject:@500]; }
    series.data = values;
    HYMCartesianModel *model = [HYMCartesianModel new]; model.categories = categories; model.series = @[series];
    NSError *error = nil;
    BOOL passed = [self.bridge configureWithModel:model error:&error];
    [self.bridge.chartView layoutIfNeeded];
    self.bridge.isZoomEnabled = YES; [self.bridge showCategoryRange:NSMakeRange(10, 20)];
    NSMutableArray<NSNumber *> *events = [NSMutableArray array];
    self.bridge.onSeriesVisibilityChanged = ^(NSString *identifier, BOOL visible) { if ([identifier isEqualToString:@"power"]) [events addObject:@(visible)]; };
    [self.bridge setSeriesVisible:NO forID:@"power"];
    series.name = @"Renamed series"; series.data = updated;
    passed &= [self.bridge updateWithModel:model preserveViewport:YES error:&error];
    [self.bridge.chartView layoutIfNeeded];
    [self.bridge setSeriesVisible:NO forID:@"power"]; // Preserved hidden state must not emit another callback.
    [self.bridge setSeriesVisible:YES forID:@"power"]; [self.bridge resetViewport];
    passed &= [events isEqualToArray:@[@NO, @YES]];
    // Invalid input must be rejected through the generated NSError signature and keep the valid chart.
    HYMCartesianModel *invalid = [HYMCartesianModel new]; invalid.series = @[series, series];
    passed &= ![self.bridge updateWithModel:invalid preserveViewport:YES error:&error];
    passed &= [error.domain isEqualToString:@"HYMCharts.Configuration"] && error.code == 1;
    __weak IntegrationController *weakSelf = self;
    self.bridge.onHit = ^(NSArray<HYMCartesianDatum *> *data) {
        HYMCartesianDatum *datum = data.firstObject;
        if (datum) weakSelf.hit.text = [NSString stringWithFormat:@"hit:%@:%ld", datum.seriesID, (long)datum.rawValue.integerValue];
    };
    NSInteger released = 0;
    for (NSInteger i = 0; i < 30; i++) {
        __weak HYMCartesianChartViewBridge *weakBridge;
        __weak UIView *weakChart;
        @autoreleasepool {
            HYMCartesianChartViewBridge *temporary = [[HYMCartesianChartViewBridge alloc] initWithKind:HYMCartesianChartKindCombined frame:CGRectMake(0, 0, 370, 310)];
            passed &= [temporary configureWithModel:model error:nil]; [temporary.chartView layoutIfNeeded];
            weakBridge = temporary; weakChart = temporary.chartView;
        }
        if (!weakBridge && !weakChart) released++;
    }
    passed &= released == 30;
    status.text = [NSString stringWithFormat:@"%@ OC | update=500 | visibility=%lu | released=%ld/30 | invalid=rejected", passed ? @"PASS" : @"FAIL", (unsigned long)events.count, (long)released];
}
@end
@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property(nonatomic, strong) UIWindow *window;
@end
@implementation AppDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)options {
    self.window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    self.window.rootViewController = [IntegrationController new]; [self.window makeKeyAndVisible]; return YES;
}
@end
int main(int argc, char *argv[]) { @autoreleasepool { return UIApplicationMain(argc, argv, nil, NSStringFromClass(AppDelegate.class)); } }
