# HYMCharts 独立接入验证

同一个 `HYMCharts.framework` 由现有 Charts 源码构建，SwiftHost 仅 `import HYMCharts`，OCHost 仅 `#import <HYMCharts/HYMCharts-Swift.h>`。两个宿主不编译 SDK 源码，不使用 `@testable`、App bridging header 或测试专用 renderer。此工程验证独立导入，不承诺旧模型适配已完成。

目录：

- `ChartsIntegration.xcodeproj`：独立于原 Demo 工程的 framework、两个 App 和 UI 测试 target。
- `SwiftHost/`：公开 Swift 接口配置、更新、显隐、真实点击；另实例化公开 SwiftUI LineChart 包装。
- `OCHost/`：全部业务源码为 Objective-C；通过生成头调用，验证错误保留有效数据与桥接对象释放。
- `UITests/`：启动两个 App，读取其验证结果，再点击图表检查更新后的值 `500`。
- `generate_project.py`：使用 Python 标准库重建工程，按确定顺序引用 77 份图表源码。保留 6 种 SwiftUI 包装；排除 Demo/Debug/参考目录及资源。新增 SDK 文件后重新运行并审阅工程差异。
- `check_product.py`：检查生成 OC 头、SwiftUI 公开类型、`@rpath` 加载路径，以及无 AA/JS/WebKit/App 依赖或 Demo/fixture 资源。

当前使用 iOS 15 deployment target、Swift 5 语言模式和 Xcode 26.3。真实业务工程的最低版本和交付方式待核对。这里只维护 Xcode framework 这一种产物；尚未打包发行版 XCFramework、SPM 或 CocoaPods。

在仓库根目录运行（替换成可用的模拟器 UUID，避免重名设备）：

```sh
python3 Examples/ChartsIntegration/generate_project.py
xcodebuild -project Examples/ChartsIntegration/ChartsIntegration.xcodeproj \
  -scheme ChartsIntegration -configuration Debug \
  -destination 'platform=iOS Simulator,id=23C39E52-9B21-4992-9121-5730E201718C,arch=arm64' \
  -derivedDataPath /tmp/HYMChartsIntegration -parallel-testing-enabled NO \
  test CODE_SIGNING_ALLOWED=NO
```

将 `Debug` 改为 `Release` 可在优化产物上运行相同测试。纯框架设备构建：

```sh
xcodebuild -project Examples/ChartsIntegration/ChartsIntegration.xcodeproj \
  -target HYMCharts -configuration Release -sdk iphoneos build \
  SYMROOT=/tmp/HYMChartsDevice/products OBJROOT=/tmp/HYMChartsDevice/objects CODE_SIGNING_ALLOWED=NO
python3 Examples/ChartsIntegration/check_product.py \
  /tmp/HYMChartsDevice/products/Release-iphoneos/HYMCharts.framework
```

业务宿主可将此工程加入 workspace，对 `HYMCharts` 建立 target 依赖并 Embed & Sign framework；Objective-C 宿主也需嵌入 Swift 运行库。不得把模拟器 framework 用于设备。当前验证为未签名构建和模拟器运行，发布签名/设备安装仍需业务工程验证。

2026-09-30：Debug 与 Release 各 2 项 UI 测试通过。两个宿主分别验证 30 次同步创建/配置/布局/释放；这不等同于长时间滚动、动画、离屏任务或内存峰值测试。iPhone arm64 Release 构建通过。独立编译仍有现有协议 existential 写法的未来 Swift 语言模式警告，迁至 Swift 6 时须处理。

[本批次证据](../../docs/evidence/charts-legacy-comparison/2026-09-30-foundation/README.md) · [字段处置清单](../../docs/charts-legacy-field-inventory.md) · [实施计划](../../docs/charts-legacy-replacement-plan.md)

2026-09-30 G1：宿主增加 `theme.stackedAreaBoundaryMode` / `bridge.stackedAreaFollowsBaseline` 的公开调用，产物检查器核对新 Swift 类型和 OC 头属性；本批 Release 编译/运行记录见 [G1 证据](../../docs/evidence/charts-legacy-comparison/2026-09-30-g1/README.md)。宿主本身仍使用原基础输入，面积几何由主工程定向用例验证。

2026-09-30 G1 跨零：新增内部 `LineStackedAreaTransitions.swift`，工程已重新生成，框架现含 76 份 Swift 源码；复用既有 Swift / OC 开关，无新增公开签名。运行证据见[跨零批次](../../docs/evidence/charts-legacy-comparison/2026-09-30-g1-crossing/README.md)。

2026-09-30 G1 前层换链：新增内部 `LineStackedAreaSignEnvelope.swift`，工程重新生成后现含 77 份 Swift 源码；配置继续复用同一开关。该文件保留已解析区间的正负连续边界，不包含 Demo fixture 或旧 AA 依赖。
