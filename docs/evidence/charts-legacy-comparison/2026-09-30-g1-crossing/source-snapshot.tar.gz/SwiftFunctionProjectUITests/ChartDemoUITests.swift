import XCTest

final class ChartDemoUITests: XCTestCase {
    override func setUpWithError() throws { continueAfterFailure = false }

    @MainActor func testSingleEntryPagesAndLiveThemeControls() {
        let app = XCUIApplication()
        app.launch()
        for (name, search, property) in [
            ("雷达图", "showsGridLines", "showsGridLines"),
            ("热力图", "showsRowLabels", "showsRowLabels"),
            ("折线图", "showsPoints", "showsPoints"),
            ("柱状图", "isEnabled", "isEnabled"),
            ("条形图", "showsDataLabels", "showsDataLabels"),
            ("混合图", "showsPoints", "showsPoints")
        ] {
            let entry = app.buttons[name]
            XCTAssertTrue(entry.waitForExistence(timeout: 5), name)
            entry.tap()
            let searchField = app.textFields["搜索属性名或分组"]
            XCTAssertTrue(searchField.waitForExistence(timeout: 5))
            searchField.tap(); searchField.typeText(search + "\n")
            let toggle = app.switches[property].firstMatch
            XCTAssertTrue(toggle.waitForExistence(timeout: 5), property)
            if !toggle.isHittable { app.swipeUp() }
            let previous = toggle.value as? String
            toggle.coordinate(withNormalizedOffset: CGVector(dx: 0.9, dy: 0.5)).tap()
            XCTAssertNotEqual(previous, toggle.value as? String)
            let attachment = XCTAttachment(screenshot: app.screenshot())
            attachment.name = "demo-\(name)-live-property"; attachment.lifetime = .keepAlways; add(attachment)
            app.navigationBars.buttons.element(boundBy: 0).tap()
        }
        XCTAssertFalse(app.buttons["高密度时间序列（288–3000 点）"].exists)
        XCTAssertFalse(app.buttons["内置图例与布局"].exists)
    }

    @MainActor func testColumnDensityPresetAndReset() {
        let app = XCUIApplication(); app.launch(); app.buttons["柱状图"].tap()
        let field = app.textFields["搜索属性名或分组"]
        XCTAssertTrue(field.waitForExistence(timeout: 5))
        field.tap(); field.typeText("3000\n")
        let preset = app.buttons["3000 点压力场景"]
        XCTAssertTrue(preset.waitForExistence(timeout: 5)); preset.tap()
        app.buttons["最近24点"].tap()
        let detail = XCTAttachment(screenshot: app.screenshot()); detail.name = "demo-column-density-detail"; detail.lifetime = .keepAlways; add(detail)
        app.buttons["总览"].tap()
        let overview = XCTAttachment(screenshot: app.screenshot()); overview.name = "demo-column-density-overview"; overview.lifetime = .keepAlways; add(overview)
        let reset = app.buttons["demo.reset"]
        if !reset.isHittable { app.swipeUp() }
        reset.tap()
        for _ in 0..<4 where !field.exists { app.collectionViews.firstMatch.swipeDown() }
        XCTAssertTrue(field.waitForExistence(timeout: 3))
        XCTAssertEqual(field.value as? String, "搜索属性名或分组")
    }
    @MainActor func testLineMinMaxPresetToggleAndDetail() {
        let app = XCUIApplication(); app.launch(); app.buttons["折线图"].tap()
        let field = app.textFields["搜索属性名或分组"]
        XCTAssertTrue(field.waitForExistence(timeout: 5))
        field.tap(); field.typeText("3000 点尖峰\n")
        let preset = app.buttons["3000 点尖峰降采样场景"]
        XCTAssertTrue(preset.waitForExistence(timeout: 5)); preset.tap()
        let overview = XCTAttachment(screenshot: app.screenshot()); overview.name = "demo-line-minmax-overview"; overview.lifetime = .keepAlways; add(overview)
        field.tap()
        field.typeText(String(repeating: XCUIKeyboardKey.delete.rawValue, count: (field.value as? String ?? "").count) + "启用 Min/Max\n")
        let toggle = app.switches["启用 Min/Max 降采样（非堆叠直线）"].firstMatch
        XCTAssertTrue(toggle.waitForExistence(timeout: 5))
        toggle.coordinate(withNormalizedOffset: CGVector(dx: 0.9, dy: 0.5)).tap()
        XCTAssertEqual(toggle.value as? String, "0")
        toggle.coordinate(withNormalizedOffset: CGVector(dx: 0.9, dy: 0.5)).tap()
        XCTAssertEqual(toggle.value as? String, "1")
        field.tap()
        field.typeText(String(repeating: XCUIKeyboardKey.delete.rawValue, count: (field.value as? String ?? "").count) + "查看尖峰\n")
        let detailButton = app.buttons["查看尖峰附近原始点"]
        XCTAssertTrue(detailButton.waitForExistence(timeout: 5)); detailButton.tap()
        let detail = XCTAttachment(screenshot: app.screenshot()); detail.name = "demo-line-minmax-detail"; detail.lifetime = .keepAlways; add(detail)
        app.buttons["总览"].tap()
    }

    @MainActor func testLineTargetPointCountInputLiveCountsAndModePriority() {
        let app = XCUIApplication(); app.launch(); app.buttons["折线图"].tap()
        auditSearch("3000 点目标", in: app)
        let preset = app.buttons["3000 点目标点数采样场景"]
        XCTAssertTrue(preset.waitForExistence(timeout: 5)); preset.tap()
        let counts = app.staticTexts["demo.lineSamplingCounts"]
        func expectCounts(_ text: String) {
            let expectation = XCTNSPredicateExpectation(predicate: NSPredicate(format: "label CONTAINS %@", text), object: counts)
            XCTAssertEqual(XCTWaiter.wait(for: [expectation], timeout: 5), .completed, text)
        }
        expectCounts("可见 3000 → 绘制 200")
        auditSearch("每系列目标绘制点数", in: app)
        let input = app.textFields["demo.input.每系列目标绘制点数 targetPointCount"]
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        input.tap(); input.typeText(String(repeating: XCUIKeyboardKey.delete.rawValue, count: 3) + "50\n")
        expectCounts("可见 3000 → 绘制 50")
        XCTAssertEqual(input.value as? String, "50")
        auditEvidence("line-target-exact-50", in: app)
        app.buttons["最近24点"].tap(); expectCounts("不足目标，不补点")
        app.buttons["总览"].tap(); expectCounts("可见 3000 → 绘制 50")
        auditSearch("bucketWidth", in: app)
        XCTAssertFalse(app.sliders.firstMatch.isEnabled)
        auditSearch("minimumVisiblePoints", in: app)
        XCTAssertFalse(app.sliders.firstMatch.isEnabled)
        auditSearch("按目标点数采样", in: app); auditToggle("按目标点数采样 targetPointCount", in: app)
        auditSearch("bucketWidth", in: app)
        XCTAssertTrue(app.sliders.firstMatch.isEnabled)
        // 原尖峰场景每 13 点缺测一次；目标 200 小于分段保护点数，必须说明超额而非静默失效。
        auditSearch("3000 点尖峰", in: app); app.buttons["3000 点尖峰降采样场景"].tap()
        auditSearch("按目标点数采样", in: app); auditToggle("按目标点数采样 targetPointCount", in: app)
        expectCounts("已超目标")
        auditEvidence("line-target-gap-protection-overflow", in: app)
    }

    @MainActor func testCartesianReuseToggleIsLiveOnEachPage() {
        let app = XCUIApplication(); app.launch()
        for name in ["折线图", "柱状图", "条形图"] {
            app.buttons[name].tap()
            let field = app.textFields["搜索属性名或分组"]
            XCTAssertTrue(field.waitForExistence(timeout: 5))
            field.tap(); field.typeText("reusesRenderingObjects\n")
            let toggle = app.switches["复用图层与标签 reusesRenderingObjects"].firstMatch
            XCTAssertTrue(toggle.waitForExistence(timeout: 5))
            XCTAssertEqual(toggle.value as? String, "1")
            toggle.coordinate(withNormalizedOffset: CGVector(dx: 0.9, dy: 0.5)).tap()
            XCTAssertEqual(toggle.value as? String, "0")
            toggle.coordinate(withNormalizedOffset: CGVector(dx: 0.9, dy: 0.5)).tap()
            XCTAssertEqual(toggle.value as? String, "1")
            let attachment = XCTAttachment(screenshot: app.screenshot())
            attachment.name = "demo-\(name)-render-reuse"; attachment.lifetime = .keepAlways; add(attachment)
            app.navigationBars.buttons.element(boundBy: 0).tap()
        }
    }

    @MainActor func testFixedDimensionsPresetScrollsAndAllowsManualRange() {
        let app = XCUIApplication(); app.launch()
        for name in ["柱状图", "条形图"] {
            app.buttons[name].tap()
            let field = app.textFields["搜索属性名或分组"]
            XCTAssertTrue(field.waitForExistence(timeout: 5))
            field.tap(); field.typeText("固定尺寸滚动示例\n")
            let preset = app.buttons["固定尺寸滚动示例（60点 × 3系列）"]
            XCTAssertTrue(preset.waitForExistence(timeout: 5)); preset.tap()
            XCTAssertTrue(app.staticTexts["00:00"].firstMatch.waitForExistence(timeout: 5))
            let before = XCTAttachment(screenshot: app.screenshot())
            before.name = "fixed-\(name)-earliest"; before.lifetime = .keepAlways; add(before)
            let chart = app.descendants(matching: .any)["demo.chart.preview"].firstMatch
            XCTAssertTrue(chart.waitForExistence(timeout: 5))
            let start = chart.coordinate(withNormalizedOffset: name == "柱状图" ? CGVector(dx: 0.8, dy: 0.5) : CGVector(dx: 0.6, dy: 0.8))
            let end = chart.coordinate(withNormalizedOffset: name == "柱状图" ? CGVector(dx: 0.2, dy: 0.5) : CGVector(dx: 0.6, dy: 0.2))
            start.press(forDuration: 0.1, thenDragTo: end)
            let after = XCTAttachment(screenshot: app.screenshot())
            after.name = "fixed-\(name)-scrolled"; after.lifetime = .keepAlways; add(after)
            XCTAssertFalse(app.staticTexts["00:00"].exists)
            app.buttons["最近24点"].tap()
            let located = XCTAttachment(screenshot: app.screenshot())
            located.name = "fixed-\(name)-manual-range"; located.lifetime = .keepAlways; add(located)
            app.buttons["总览"].tap()
            XCTAssertTrue(app.staticTexts["00:00"].firstMatch.waitForExistence(timeout: 5))
            app.navigationBars.buttons.element(boundBy: 0).tap()
        }
    }

    @MainActor func testSemanticPresetAndFormatPanelAreLive() {
        let app = XCUIApplication(); app.launch(); app.buttons["柱状图"].tap()
        let field = app.textFields["搜索属性名或分组"]
        XCTAssertTrue(field.waitForExistence(timeout: 5))
        field.tap(); field.typeText("数据语义\n")
        let preset = app.buttons["数据语义：100 + 50 堆叠"]
        XCTAssertTrue(preset.waitForExistence(timeout: 5)); preset.tap()
        let chart = app.descendants(matching: .any)["demo.chart.preview"].firstMatch
        chart.coordinate(withNormalizedOffset: CGVector(dx: 0.25, dy: 0.25)).tap()
        let readout = app.staticTexts["demo.hit"]
        XCTAssertTrue(readout.label.contains("原值"), readout.label)
        XCTAssertTrue(readout.label.contains("能源"), readout.label)
        let evidence = XCTAttachment(screenshot: app.screenshot())
        evidence.name = "semantic-stacked-hit"; evidence.lifetime = .keepAlways; add(evidence)
        field.tap()
        field.typeText(String(repeating: XCUIKeyboardKey.delete.rawValue, count: (field.value as? String ?? "").count) + "仅展示绝对值\n")
        let toggle = app.switches["仅展示绝对值"].firstMatch
        XCTAssertTrue(toggle.waitForExistence(timeout: 5))
        XCTAssertEqual(toggle.value as? String, "0")
        toggle.coordinate(withNormalizedOffset: CGVector(dx: 0.9, dy: 0.5)).tap()
        XCTAssertEqual(toggle.value as? String, "1")
    }

    @MainActor func testObjectiveCCartesianCallbackForAllKinds() {
        let app = XCUIApplication(); app.launch(); app.buttons["Objective-C 接入"].tap()
        XCTAssertTrue(app.buttons["轴系验证"].waitForExistence(timeout: 5))
        app.buttons["轴系验证"].tap()
        let selector = app.segmentedControls["oc.cartesian.kind"]
        XCTAssertTrue(selector.waitForExistence(timeout: 5))
        for kind in ["柱状", "折线", "条形", "混合"] {
            selector.buttons[kind].tap()
            let chart = app.descendants(matching: .any)["oc.cartesian.chart"].firstMatch
            chart.coordinate(withNormalizedOffset: CGVector(dx: 0.25, dy: 0.4)).tap()
            let readout = app.staticTexts["oc.cartesian.hit"]
            XCTAssertTrue(readout.label.contains("raw="), readout.label)
            XCTAssertTrue(readout.label.contains("draw="), readout.label)
            let evidence = XCTAttachment(screenshot: app.screenshot())
            evidence.name = "oc-semantic-" + kind; evidence.lifetime = .keepAlways; add(evidence)
        }
    }

    @MainActor func testCombinedGroupsPresetAndIndependentStylePanel() {
        let app = XCUIApplication(); app.launch(); app.buttons["混合图"].tap()
        let field = app.textFields["搜索属性名或分组"]
        XCTAssertTrue(field.waitForExistence(timeout: 5))
        field.tap(); field.typeText("两组堆叠\n")
        let preset = app.buttons["两组堆叠与目标线"]
        XCTAssertTrue(preset.waitForExistence(timeout: 5)); preset.tap()
        let chart = app.descendants(matching: .any)["demo.chart.preview"].firstMatch
        chart.coordinate(withNormalizedOffset: CGVector(dx: 0.3, dy: 0.4)).tap()
        XCTAssertTrue(app.staticTexts["demo.hit"].label.contains("原值"))
        let grouped = XCTAttachment(screenshot: app.screenshot()); grouped.name = "combined-grouped-dual-axis"
        grouped.lifetime = .keepAlways; add(grouped)
        field.tap()
        field.typeText(String(repeating: XCUIKeyboardKey.delete.rawValue, count: (field.value as? String ?? "").count) + "自定义系列线宽\n")
        let toggle = app.switches["自定义系列线宽"].firstMatch
        XCTAssertTrue(toggle.waitForExistence(timeout: 5)); XCTAssertTrue(toggle.isEnabled)
        let initial = toggle.value as? String
        XCTAssertTrue(initial == "0" || initial == "1")
        toggle.coordinate(withNormalizedOffset: CGVector(dx: 0.9, dy: 0.5)).tap()
        XCTAssertEqual(toggle.value as? String, initial == "1" ? "0" : "1")
        toggle.coordinate(withNormalizedOffset: CGVector(dx: 0.9, dy: 0.5)).tap()
        XCTAssertEqual(toggle.value as? String, initial)
    }

    @MainActor func testAutoGapPresetAndPolicyPickerOnLineAndCombined() {
        let app = XCUIApplication()
        for page in ["折线图", "混合图"] {
            app.launch(); app.buttons[page].tap()
            let search = app.textFields["搜索属性名或分组"]
            XCTAssertTrue(search.waitForExistence(timeout: 5))
            search.tap(); search.typeText("autoGap\n")
            let preset = app.buttons["11/12/13 空点 autoGap 场景"]
            XCTAssertTrue(preset.waitForExistence(timeout: 5)); preset.tap()
            let picker = app.buttons.matching(NSPredicate(format: "label CONTAINS %@", "缺测策略 autoGap")).firstMatch
            XCTAssertTrue(picker.waitForExistence(timeout: 5))
            XCTAssertTrue(picker.label.contains("按空点数量"), picker.label)
            for mode in ["全部断开", "全部连接", "按缺测时长", "跟随跨空值连线"] {
                picker.tap(); app.buttons[mode].tap()
                XCTAssertTrue(picker.label.contains(mode), picker.label)
            }
            picker.tap(); app.buttons["按空点数量"].tap()
            let evidence = XCTAttachment(screenshot: app.screenshot())
            evidence.name = "auto-gap-11-12-13-" + page
            evidence.lifetime = .keepAlways; add(evidence)
        }
    }

    @MainActor func testColorZonesAndSmoothNegativePresetsOnLineAndCombined() {
        let app = XCUIApplication()
        for page in ["折线图", "混合图"] {
            app.launch(); app.buttons[page].tap()
            let field = app.textFields["搜索属性名或分组"]
            XCTAssertTrue(field.waitForExistence(timeout: 5))
            func search(_ query: String) {
                if !field.isHittable { app.collectionViews.firstMatch.swipeDown() }
                let current = field.value as? String ?? ""
                // 使用短关键词，避免长文本点中间时将光标放在词中。
                field.tap()
                field.typeText(String(repeating: XCUIKeyboardKey.delete.rawValue,
                                      count: current == "搜索属性名或分组" ? 0 : current.count) + query + "\n")
                XCTAssertEqual(field.value as? String, query)
            }
            for (query, preset) in [("X 分区", "X 分区曲线面积 zones 场景"),
                                    ("Y 分区", "Y 分区曲线面积 zones 场景"),
                                    ("曲线负值", "曲线负值换色 zones 场景")] {
                search(query)
                let button = app.buttons[preset]
                XCTAssertTrue(button.waitForExistence(timeout: 5)); button.tap()
                let evidence = XCTAttachment(screenshot: app.screenshot())
                evidence.name = page + "-" + preset; evidence.lifetime = .keepAlways; add(evidence)
            }
            search("颜色分区")
            let picker = app.buttons.matching(NSPredicate(format: "label CONTAINS %@", "颜色分区 zones")).firstMatch
            XCTAssertTrue(picker.waitForExistence(timeout: 5))
            XCTAssertTrue(picker.label.contains("关闭"))
            for mode in ["X 原始索引", "Y 绘制值", "关闭"] {
                picker.tap(); app.buttons[mode].tap()
                XCTAssertTrue(picker.label.contains(mode), picker.label)
            }
            picker.tap(); app.buttons["X 原始索引"].tap()
            search("分区面积")
            let fill = app.switches["分区面积渐变"].firstMatch
            XCTAssertTrue(fill.waitForExistence(timeout: 5))
            fill.coordinate(withNormalizedOffset: CGVector(dx: 0.9, dy: 0.5)).tap()
            XCTAssertEqual(fill.value as? String, "1")
            fill.coordinate(withNormalizedOffset: CGVector(dx: 0.9, dy: 0.5)).tap()
            XCTAssertEqual(fill.value as? String, "0")
        }
    }


    @MainActor private func auditSearch(_ query: String, in app: XCUIApplication) {
        let field = app.textFields["demo.search"]
        XCTAssertTrue(field.waitForExistence(timeout: 5))
        let old = field.value as? String ?? ""
        field.tap()
        field.typeText(String(repeating: XCUIKeyboardKey.delete.rawValue, count: old == "搜索属性名或分组" ? 0 : old.count) + query + "\n")
    }
    @MainActor private func auditToggle(_ label: String, in app: XCUIApplication) {
        let toggle = app.switches[label].firstMatch
        XCTAssertTrue(toggle.waitForExistence(timeout: 5))
        if !toggle.isHittable { app.collectionViews.firstMatch.swipeUp() }
        toggle.coordinate(withNormalizedOffset: CGVector(dx: 0.9, dy: 0.5)).tap()
    }
    @MainActor private func auditEvidence(_ name: String, in app: XCUIApplication) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name; attachment.lifetime = .keepAlways; add(attachment)
    }

    @MainActor func testStackedAreaSeamPresetInLineAndCombinedDemos() {
        let app = XCUIApplication()
        for page in ["折线图", "混合图"] {
            app.launch(); app.buttons[page].tap()
            auditSearch("接缝", in: app)
            let preset = app.buttons["正负与缺测堆叠面积接缝场景"]
            XCTAssertTrue(preset.waitForExistence(timeout: 5)); preset.tap()
            auditSearch("当前状态", in: app)
            XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "实际最长 12 点")).firstMatch.exists)
            XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "共享区间复用前层原曲线")).firstMatch.exists)
            auditEvidence("stacked-area-seams-" + page, in: app)
            auditSearch("系列线宽", in: app)
            auditToggle("自定义系列线宽", in: app)
            XCTAssertEqual(app.switches["自定义系列线宽"].firstMatch.value as? String, "1")
            app.buttons["恢复默认配置"].tap()
            auditSearch("当前状态", in: app)
            XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "实际最长 24 点")).firstMatch.exists)
            app.terminate()
        }
    }

    @MainActor func testThinStackedAreaBoundaryComparisonInBothDemos() {
        auditStackedAreaComparison(query: "薄层", preset: "薄层混合线型面积对照场景", evidence: "thin-area")
    }

    @MainActor func testCrossingStackedAreaBoundaryComparisonInBothDemos() {
        auditStackedAreaComparison(query: "跨零正负", preset: "跨零正负基线面积对照场景", evidence: "crossing-area")
    }

    @MainActor private func auditStackedAreaComparison(query: String, preset: String, evidence: String) {
        let app = XCUIApplication()
        for page in ["折线图", "混合图"] {
            app.launch(); app.buttons[page].tap()
            auditSearch(query, in: app)
            let button = app.buttons[preset]
            XCTAssertTrue(button.waitForExistence(timeout: 5)); button.tap()
            auditSearch("当前状态", in: app)
            XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "当前边界模式：沿基线叠加")).firstMatch.exists)
            auditEvidence(evidence + "-follow-baseline-" + page, in: app)
            auditSearch("堆叠面积边界", in: app)
            app.buttons.matching(NSPredicate(format: "label CONTAINS %@", "stackedAreaBoundaryMode")).firstMatch.tap()
            app.buttons["独立插值（兼容）"].tap()
            auditSearch("当前状态", in: app)
            XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "当前边界模式：独立插值（兼容）")).firstMatch.exists)
            auditEvidence(evidence + "-independent-" + page, in: app)
            app.buttons["恢复默认配置"].tap()
            auditSearch("当前状态", in: app)
            XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "实际最长 24 点")).firstMatch.exists)
            app.terminate()
        }
    }

    @MainActor func testLineAuditGapAndZoneDependenciesRecover() {
        let app = XCUIApplication(); app.launch(); app.buttons["折线图"].tap()
        auditSearch("X 分区", in: app); app.buttons["X 分区曲线面积 zones 场景"].tap()
        auditSearch("负值颜色", in: app)
        XCTAssertFalse(app.switches["自定义 负值颜色"].firstMatch.isEnabled)
        XCTAssertTrue(app.staticTexts["demo.rule.自定义 负值颜色"].exists)
        auditEvidence("line-audit-zone-precedence", in: app)
        auditSearch("11/12", in: app); app.buttons["11/12/13 空点 autoGap 场景"].tap()
        auditSearch("跨空值连线", in: app)
        XCTAssertFalse(app.switches["跨空值连线"].firstMatch.isEnabled)
        auditSearch("缺测策略", in: app)
        app.buttons.matching(NSPredicate(format: "label CONTAINS %@", "缺测策略 autoGap")).firstMatch.tap()
        app.buttons["跟随跨空值连线"].tap()
        auditSearch("跨空值连线", in: app)
        XCTAssertTrue(app.switches["跨空值连线"].firstMatch.isEnabled)
        auditToggle("跨空值连线", in: app)
        XCTAssertEqual(app.switches["跨空值连线"].firstMatch.value as? String, "1")
        auditEvidence("line-audit-gap-restored", in: app)
    }

    @MainActor func testLineAuditAxisPriorityAndDisabledReasons() {
        let app = XCUIApplication(); app.launch(); app.buttons["折线图"].tap()
        auditSearch("固定刻度", in: app)
        XCTAssertFalse(app.switches["固定刻度间隔（需固定值域）"].firstMatch.isEnabled)
        auditSearch("固定值域", in: app); auditToggle("固定值域", in: app)
        auditSearch("固定刻度", in: app)
        XCTAssertTrue(app.switches["固定刻度间隔（需固定值域）"].firstMatch.isEnabled)
        auditToggle("固定刻度间隔（需固定值域）", in: app)
        auditSearch("刻度数", in: app)
        XCTAssertFalse(app.switches["自定义刻度数"].firstMatch.isEnabled)
        XCTAssertTrue(app.staticTexts["demo.rule.自定义刻度数"].exists)
        auditEvidence("line-audit-axis-priority", in: app)
        auditSearch("固定刻度", in: app); auditToggle("固定刻度间隔（需固定值域）", in: app)
        auditSearch("刻度数", in: app)
        XCTAssertTrue(app.switches["自定义刻度数"].firstMatch.isEnabled)
    }

    @MainActor func testLineAuditSceneSwitchClearsOldDataAndStyle() {
        let app = XCUIApplication(); app.launch(); app.buttons["折线图"].tap()
        auditSearch("X 分区", in: app); app.buttons["X 分区曲线面积 zones 场景"].tap()
        auditSearch("3000 点尖峰", in: app); app.buttons["3000 点尖峰降采样场景"].tap()
        XCTAssertTrue(app.staticTexts["demo.lineSamplingStatus"].label.contains("配置可用"))
        auditSearch("当前状态", in: app)
        XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "实际最长 3000 点")).firstMatch.exists)
        auditEvidence("line-audit-preset-isolation-3000", in: app)
        app.buttons["最近24点"].tap()
        let chart = app.descendants(matching: .any)["demo.chart.preview"].firstMatch
        chart.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5)).tap()
        XCTAssertTrue(app.staticTexts["demo.hit"].label.contains("原值"))
        auditEvidence("line-audit-detail-original-hit", in: app)
    }

    @MainActor func testLineAuditSystemFontAndPopupControls() {
        let app = XCUIApplication(); app.launch(); app.buttons["折线图"].tap()
        auditSearch("titleFont 字体", in: app)
        let font = app.buttons.matching(NSPredicate(format: "label CONTAINS %@", "titleFont 字体")).firstMatch
        font.tap(); app.buttons["系统等宽"].tap()
        XCTAssertTrue(font.label.contains("系统等宽"))
        font.tap(); app.buttons["系统常规"].tap()
        XCTAssertTrue(font.label.contains("系统常规"))
        auditSearch("容器弹窗", in: app); auditToggle("容器弹窗", in: app)
        XCTAssertEqual(app.switches["容器弹窗"].firstMatch.value as? String, "0")
        auditSearch("表头模板", in: app)
        let header = app.textFields["demo.input.表头模板"]
        XCTAssertTrue(header.waitForExistence(timeout: 5))
        XCTAssertFalse(header.isEnabled)
        auditSearch("容器弹窗", in: app); auditToggle("容器弹窗", in: app)
        auditSearch("弹窗回调", in: app)
        app.buttons.matching(NSPredicate(format: "label CONTAINS %@", "弹窗回调预设")).firstMatch.tap()
        app.buttons["位置回调"].tap()
        auditSearch("共享提示", in: app)
        XCTAssertFalse(app.switches["共享提示"].firstMatch.isEnabled)
        let chart = app.descendants(matching: .any)["demo.chart.preview"].firstMatch
        chart.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5)).tap()
        XCTAssertTrue(app.staticTexts["demo.hit"].label.contains("位置"))
        let expand = app.buttons["demo.hit.expand"]
        XCTAssertTrue(expand.waitForExistence(timeout: 5)); expand.tap()
        XCTAssertEqual(expand.label, "收起读数")
        auditEvidence("line-audit-location-popup-mode", in: app)
        expand.tap(); XCTAssertEqual(expand.label, "展开读数")
    }

    @MainActor func testPreviousValuesAndPinnedTooltipOnAllCartesianPages() {
        let app = XCUIApplication()
        for page in ["折线图", "柱状图", "条形图", "混合图"] {
            app.launch(); app.buttons[page].tap()
            auditSearch("前值与置顶", in: app)
            let preset = app.buttons["前值与置顶提示场景"]
            XCTAssertTrue(preset.waitForExistence(timeout: 5)); preset.tap()
            let chart = app.descendants(matching: .any)["demo.chart.preview"].firstMatch
            chart.coordinate(withNormalizedOffset: CGVector(dx: 0.54, dy: 0.35)).tap()
            let popup = app.descendants(matching: .any)["chart.tooltip.fixedTop"].firstMatch
            XCTAssertTrue(popup.waitForExistence(timeout: 5))
            XCTAssertEqual(popup.frame.minY, chart.frame.minY + 8, accuracy: 1)
            let report = app.staticTexts["demo.hit"].label
            XCTAssertTrue(report.contains("08:05"), report)
            XCTAssertTrue(report.contains("取值 08:00"), report)
            XCTAssertTrue(report.contains("原值 120.0"), report)
            XCTAssertTrue(report.contains("100 W"), report)
            XCTAssertTrue(report.contains("60 W"), report)
            auditEvidence("previous-pinned-" + page, in: app)
            auditSearch("fixedTopInset", in: app)
            XCTAssertTrue(app.sliders.firstMatch.isEnabled)
            app.sliders.firstMatch.adjust(toNormalizedSliderPosition: 0.5)
            chart.coordinate(withNormalizedOffset: CGVector(dx: 0.54, dy: 0.35)).tap()
            XCTAssertTrue(popup.waitForExistence(timeout: 5))
            XCTAssertEqual(popup.frame.minY, chart.frame.minY + 20, accuracy: 1)
            auditEvidence("previous-pinned-inset-" + page, in: app)
            app.terminate()
        }
    }

    @MainActor func testRichTooltipRulesAndScrollingOnAllCartesianPages() {
        let app = XCUIApplication()
        for page in ["折线图", "柱状图", "条形图", "混合图"] {
            app.launch(); app.buttons[page].tap()
            auditSearch("富内容提示", in: app)
            let preset = app.buttons["富内容提示与逐点规则场景"]
            XCTAssertTrue(preset.waitForExistence(timeout: 5)); preset.tap()
            let chart = app.descendants(matching: .any)["demo.chart.preview"].firstMatch
            chart.coordinate(withNormalizedOffset: CGVector(dx: 0.45, dy: 0.35)).tap()
            let popup = app.scrollViews["chart.tooltip.columns"].firstMatch
            XCTAssertTrue(popup.waitForExistence(timeout: 5))
            XCTAssertTrue(app.staticTexts["demo.hit"].label.contains("采样"))
            XCTAssertGreaterThan(popup.staticTexts.count, 0)
            auditEvidence("rich-tooltip-" + page, in: app)

            // 增加组内行距并压低图表，让末行只能通过内容区滚动访问。
            auditSearch("提示行间距", in: app)
            app.sliders.firstMatch.adjust(toNormalizedSliderPosition: 1)
            auditSearch("测量并追加图例高度", in: app)
            auditToggle("测量并追加图例高度", in: app)
            auditSearch("基础图表高度", in: app)
            app.sliders.firstMatch.adjust(toNormalizedSliderPosition: 0)
            chart.coordinate(withNormalizedOffset: CGVector(dx: 0.45, dy: 0.35)).tap()
            XCTAssertTrue(popup.waitForExistence(timeout: 5))
            let before = app.staticTexts["demo.hit"].label
            let lastRow = popup.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "备用")).firstMatch
            let previousY = lastRow.frame.minY
            popup.swipeUp()
            XCTAssertTrue(popup.exists, "内容滚动不应触发图表拖动或取消选择")
            XCTAssertEqual(app.staticTexts["demo.hit"].label, before)
            XCTAssertLessThan(lastRow.frame.minY, previousY - 1, "确认实际发生内部滚动")
            XCTAssertTrue(lastRow.isHittable)
            auditEvidence("rich-tooltip-scrolled-" + page, in: app)
            app.terminate()
        }
    }

    @MainActor func testGroupedTooltipAndImageLegendPresetOnAllCartesianPages() {
        let app = XCUIApplication()
        for page in ["折线图", "柱状图", "条形图", "混合图"] {
            app.launch(); app.buttons[page].tap()
            auditSearch("分组提示", in: app)
            let preset = app.buttons["分组提示与图片图例场景"]
            XCTAssertTrue(preset.waitForExistence(timeout: 5)); preset.tap()
            let chart = app.descendants(matching: .any)["demo.chart.preview"].firstMatch
            chart.coordinate(withNormalizedOffset: CGVector(dx: 0.45, dy: 0.35)).tap()
            let readout = app.staticTexts["demo.hit"]
            XCTAssertTrue(readout.label.contains("小计"), readout.label)
            XCTAssertTrue(readout.label.contains("环境"), readout.label)
            auditEvidence("grouped-presentation-" + page, in: app)
            let solar = app.buttons["光伏"].firstMatch
            XCTAssertTrue(solar.waitForExistence(timeout: 5)); solar.tap()
            XCTAssertEqual(solar.value as? String, "已隐藏")
            chart.coordinate(withNormalizedOffset: CGVector(dx: 0.45, dy: 0.35)).tap()
            XCTAssertFalse(readout.label.contains("小计"), readout.label)
            solar.tap(); XCTAssertEqual(solar.value as? String, "已显示")
            auditSearch("按业务组显示提示", in: app)
            auditToggle("按业务组显示提示", in: app)
            chart.coordinate(withNormalizedOffset: CGVector(dx: 0.45, dy: 0.35)).tap()
            XCTAssertFalse(readout.label.contains("小计"), readout.label)
            app.terminate()
        }
    }

}
